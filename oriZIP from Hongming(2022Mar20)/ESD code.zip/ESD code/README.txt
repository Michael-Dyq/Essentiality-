1. Setup the environment with environment.yml.
2. put the data under the same folder of the code and then run "data_process.py"
3. Then, you should be able to replicate our results with different scripts respectively.
4. For experiments with GPT-3, Due to the double-policy policy, you need to setup an account with OPENAI and setup your own API key.